@extends('layouts.main')
@section('main-container')
<div class="main-panel">
    <div class="content-wrapper">
<h1>hvgh</h1>
@endsection